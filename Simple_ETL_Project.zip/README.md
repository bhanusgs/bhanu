# Simple ETL Project: Customer Order Pipeline

## Objective
Build a small ETL pipeline using Airbyte (or Python), dbt, and Dagster.

## Data Files
- `orders.csv`: Order transactions
- `products.json`: Product metadata

## Steps
1. Load `orders.csv` and `products.json` into PostgreSQL raw tables.
2. Use dbt to model and join into a final `order_summary` table with:
   - order_id, customer_id, product_name, category, quantity, price, total_amount
3. Orchestrate using Dagster (at least run-once manually).

## Deliverables
- GitHub repo with pipeline code
- Screenshot of final `order_summary` table
